input_year = int(input())
def is_leap_year(input_year):
    if input_year % 400 == 0:
        return True
    if input_year % 100 == 0:
        return False
    if input_year % 4 == 0:
        return True
    return False
print (input_year, "- leap year" if is_leap_year(input_year) else "- not a leap year")
