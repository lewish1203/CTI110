milesPerGallon = float(input())
dollarsPerGallon = float(input())
mileage1 = (20 / milesPerGallon) * dollarsPerGallon
mileage2 = (75 / milesPerGallon) * dollarsPerGallon
mileage3 = (500 / milesPerGallon) * dollarsPerGallon
print('{:.2f} {:.2f} {:.2f}'.format(mileage1, mileage2, mileage3))