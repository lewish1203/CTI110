Username = input()
print("Hello" , Username , "and welcome to CS Online!")